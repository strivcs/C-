#include <iostream>
//#include <fstream>
#include <string>
#include <stdlib.h>
#include <time.h>

using namespace std;
#include"��ͷ.h"
int main() 
{
	srand(time(NULL));
	GA temp;
	temp.Run();
	system("pause");
	return 0;
}