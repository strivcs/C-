#include<iostream>
#include<string>
#include<stdlib.h>
#include<chrono>  
using namespace std;
using namespace chrono;
const unsigned short int PACK_MAX_W1 = 800;                  
const unsigned short int PACK_MAX_W2 = 650;
const unsigned short int PACK_MAX_W3 = 550;
const unsigned short int PACK_MAX_W4 = 550;
const unsigned short int PACK_MAX_W5 = 650;
const unsigned char NUM = 50;
const unsigned short int MAX_GENERATION = 1000;//�Ŵ�������
const unsigned short int PS = 2000;        //��Ⱥ��ģ
const float PC = 0.80;                      //������
const float PV = 0.20;                      //������

const int value[NUM] = { 560,1125,300,620,2100,431,68,328,47,122,322,196,41,25,425,4260,416,115,82,22,631,132,420,86,42,103,215,81,91,26,49,420,316,72,71,49,108,116,90,738,1811,430,3060,215,58,296,620,418,47,81 };
const int w1[NUM] = { 40,91,10, 30, 160, 20, 3, 12, 3, 18, 9, 25, 1, 1, 10, 280, 10, 8, 1, 1, 49, 8, 21,6 ,1,5, 10, 8, 2, 1, 0, 10, 42, 6, 4, 8, 0, 10 ,1, 40, 86, 11, 120, 8, 3, 32, 28, 13, 2, 4 };
const int w2[NUM] = { 16, 92, 41, 16, 150, 23, 4, 18, 6, 0, 12, 8, 2, 1, 0, 200, 20, 6, 2, 1, 70, 9, 22 ,4,1 ,5,10, 6, 4, 0, 4, 12, 8, 4, 3, 0, 10, 0, 6, 28, 93, 9 ,30, 22 ,0, 36, 45, 13, 2 ,2 };
const int w3[NUM]= { 38 ,39, 32, 71, 80, 26, 5, 40, 8, 12, 30, 15, 0, 1, 23, 100, 0, 20, 3, 0, 40, 6, 8, 0,6 ,4,22 ,4 ,6 ,1 ,5 ,14 ,8 ,2 ,8 ,0 ,20 ,0 ,0 ,6 ,12, 6 ,80 ,13 ,6 ,22 ,14 ,0 ,1 ,2 };
const int w4[NUM]= { 8, 71, 30, 60, 200, 18, 6, 30, 4 ,8, 31, 6, 3, 0 ,18 ,60 ,21 ,4 ,0 ,2 ,32 ,15 ,31 ,2,2 ,7,8 ,2 ,8 ,0 ,2 ,8 ,6 ,7 ,1 ,0 ,0 ,20 ,8 ,14 ,20 ,2 ,40 ,6 ,1 ,14 ,20, 12 ,0 ,1 };
const int w5[NUM]= { 38 ,52 ,30, 42, 170, 9, 7, 20, 0, 3, 21, 4, 1, 2, 14, 310, 8, 4, 6, 1, 18, 15, 38, 10,4 ,8,6 ,0 ,0 ,3 ,0 ,10 ,6 ,1 ,3 ,0 ,3 ,5 ,4 ,0 ,30 ,12 ,16 ,18 ,3 ,16 ,22 ,30 ,4 ,0 };
//�������01
int pp() {
	float p;
	p = rand() % 1000 / 1000.0;
	if (p < 0.9)
	{//cout<<0<<" ";
		return 0;
	}
	else
	{//cout<<1<<" ";
		return 1;
	}
}
//������
class Entity {
public:
	int fit;
	unsigned short int sum_w1;
	unsigned short int sum_w2;
	unsigned short int sum_w3;
	unsigned short int sum_w4;
	unsigned short int sum_w5;
	unsigned short int sum_val;
	unsigned short int gene[NUM];
	unsigned short int _count;
	Entity() {
		fit = 0;
		sum_w1= 0;
		sum_w2 = 0;
		sum_w3 = 0;
		sum_w4 = 0;
		sum_w5 = 0;
		sum_val = 0;
		int i;
		for (i = 0; i < NUM; i++)
			gene[i] = 0;
	}
};

//�Ŵ��㷨��
class GA 
{
private:
	Entity zq[PS];                          //��Ⱥ
	Entity max_single;                      //���Ÿ���
public:
	void Init();
	//��������ֵ����
	unsigned short int Cal_SingleValue(int id);
	unsigned short int Cal_SingleW1(int id);
	unsigned short int Cal_SingleW2(int id);
	unsigned short int Cal_SingleW3(int id);
	unsigned short int Cal_SingleW4(int id);
	unsigned short int Cal_SingleW5(int id);
	//���������Ӧ��
	void Cal_Fitness();
	//�����ֵ������
	void Cal_Maxval_Single(int _generation);
	//ѡ��
	void Select();
	//�Ƿ񽻲�
	bool IsCross() { return ((rand() % 1000 / 1000.0) <= PC); }
	//����
	void Cross();
	//�Ƿ����
	bool IsVariation() { return ((rand() % 1000 / 1000.0) <= PV); }
	//����
	void Variation();
	//�����Ŵ���ÿ������ʱ���
	void Run() {
		auto start = system_clock::now();
		int i;
		//readData();
		Init();
		for (i = 0; i < MAX_GENERATION; i++)
		{
			Cal_Fitness();
			Cal_Maxval_Single(i);
			Select();
			Cross();
			if (i % 5 == 0 && i != 0) {
				Variation();
			}
		}
		Cal_Fitness();
		Cal_Maxval_Single(MAX_GENERATION);
		cout << "The best value is:" << max_single.fit << endl;
		cout << "The best entity's gene is:" << endl;
		for (int i = 0; i < NUM; i++) 
		{
			cout << max_single.gene[i];
			if (i != NUM - 1)
				cout << " ";
		}
		std::cout << std::endl;
		cout << max_single.sum_w1 << endl <<
			max_single.sum_w2 << endl <<
			max_single.sum_w3 << endl <<
			max_single.sum_w4 << endl <<
			max_single.sum_w5 << endl <<
			max_single.sum_val << endl;
		cout << endl << "The best entity is in the " << max_single._count << " generation." << endl;
		auto end = system_clock::now();
		auto duration = duration_cast<microseconds>(end - start);
		std::cout << "������ʱ��" << double(duration.count()) * microseconds::period::num / microseconds::period::den << "s" << std::endl;
	}
};


void GA::Init()
{
	unsigned short int i, j, w1sum, w2sum,w3sum, w4sum, w5sum;
	for (i = 0; i < PS; i++)
	{
		w1sum = 0;
		w2sum = 0;
		w3sum = 0;
		w4sum = 0;
		w5sum = 0;
		for (j = 0; j < NUM; j++)
		{
			zq[i].gene[j] = pp();
			w1sum += zq[i].gene[j] * w1[j];
			w2sum += zq[i].gene[j] * w2[j];
			w3sum += zq[i].gene[j] * w3[j];
			w4sum += zq[i].gene[j] * w4[j];
			w5sum += zq[i].gene[j] * w5[j];
		}
		if (w1sum > PACK_MAX_W1 || w2sum > PACK_MAX_W2
			|| w3sum > PACK_MAX_W3 || w4sum > PACK_MAX_W4
			|| w5sum > PACK_MAX_W5)    //�������������ĸ���
		{
			i--;
		}
	}
}

unsigned short int GA::Cal_SingleValue(int id) {
	int j, valuesum = 0;
	for (j = 0; j < NUM; j++) {
		valuesum += zq[id].gene[j] * value[j];
	}
	zq[id].sum_val = valuesum;
	return valuesum;
}

unsigned short int GA::Cal_SingleW1(int id) {
	int j, w1sum = 0;
	for (j = 0; j < NUM; j++) {
		w1sum += zq[id].gene[j] * w1[j];
	}
	zq[id].sum_w1 = w1sum;
	return w1sum;
}
unsigned short int GA::Cal_SingleW2(int id) {
	int j, w2sum = 0;
	for (j = 0; j < NUM; j++) {
		w2sum += zq[id].gene[j] * w2[j];
	}
	zq[id].sum_w2 = w2sum;
	return w2sum;
}
unsigned short int GA::Cal_SingleW3(int id) {
	int j, w3sum = 0;
	for (j = 0; j < NUM; j++) {
		w3sum += zq[id].gene[j] * w3[j];
	}
	zq[id].sum_w3 = w3sum;
	return w3sum;
}
unsigned short int GA::Cal_SingleW4(int id) {
	int j, w4sum = 0;
	for (j = 0; j < NUM; j++) {
		w4sum += zq[id].gene[j] * w4[j];
	}
	zq[id].sum_w4 = w4sum;
	return w4sum;
}

unsigned short int GA::Cal_SingleW5(int id) 
{
	int j, w5sum = 0;
	for (j = 0; j < NUM; j++) 
	{
		w5sum += zq[id].gene[j] * w5[j];
	}
	zq[id].sum_w5 = w5sum;
	return w5sum;
}

void GA::Cal_Fitness()
{
	int i, val,a1,a2,a3,a4,a5;
	for (i = 0; i < PS; i++)
	{
		a1 = Cal_SingleW1(i);
		a2 = Cal_SingleW2(i);
		a3 = Cal_SingleW3(i);
		a4 = Cal_SingleW4(i);
		a5 = Cal_SingleW5(i);
		val = Cal_SingleValue(i);
		if (a1 > PACK_MAX_W1 || a2 > PACK_MAX_W2
			|| a3 > PACK_MAX_W3 || a4 > PACK_MAX_W4
			|| a5 > PACK_MAX_W5)
		{
			zq[i].fit = 0;
			continue;
		}
		zq[i].fit = val;
		//cout<<zq[i].fit<<endl;
	}
}

void GA::Cal_Maxval_Single(int _generation) {
	int i, maxval = zq[0].fit, id = 0;
	for (i = 0; i < PS; i++)
		if (maxval < zq[i].fit) {
			maxval = zq[i].fit;
			id = i;
		}
	if (maxval > max_single.fit) {
		max_single = zq[id];
		max_single._count = _generation;
	}
}

void GA::Select() {

	int fit_sum = 0, i, j;
	float rand_rate, cur_rate;
	float selected_rate[PS];
	Entity new_zq[PS];

	for (i = 0; i < PS; i++) {
		fit_sum += zq[i].fit;
	}
	//ʹ���ֶķ�����ѡ��
	selected_rate[0] = float(zq[0].fit) / fit_sum;

	for (i = 1; i < PS; i++) {
		cur_rate = selected_rate[i - 1] + float(zq[i].fit) / fit_sum;
		selected_rate[i] = cur_rate;
	}

	for (i = 0; i < PS; i++) {
		rand_rate = (rand() % 1000 / 1000.0);
		for (j = 0; j < PS; j++) {
			if (rand_rate <= selected_rate[j]) {
				new_zq[i] = zq[j];
				break;
			}
		}
	}
	for (i = 0; i < PS; i++) {
		zq[i] = new_zq[i];
		//cout<<zq[i].fit<<endl;
	}

}

void GA::Cross() {
	int i, j;
	for (i = 0; i < PS - 1; i += 2) {
		Entity en1 = zq[i];
		Entity en2 = zq[i + 1];

		for (j = 0; j < NUM; j++) {
			if (IsCross()) {
				int tmp = en1.gene[j];
				en1.gene[j] = en2.gene[j];
				en2.gene[j] = tmp;
			}
		}
		zq[i] = en1;
		zq[i + 1] = en2;
	}
}

void GA::Variation() {
	int i, j;
	for (i = 0; i < PS; i++) {
		if (IsVariation()) {
			for (j = 0; j < NUM; j++) {
				if (IsVariation()) {
					zq[i].gene[j] = zq[i].gene[j] ? 0 : 1;
				}
			}
		}
	}
}
